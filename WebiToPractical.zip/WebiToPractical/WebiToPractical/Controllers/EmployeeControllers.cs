﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using WebiToPractical.Models;




namespace WebiToPractical.Controllers
{
    public class EmployeeControllers : Controller
    {
        public object Connection { get; private set; }

        public IActionResult Index()
        {

            List<Employee> eomplyees = new List<Employee>();

            using (SqlConnection connection = new SqlConnection("Practical"))
            {
                string query = "SELECT * FROM EMPLOYEE";
                SqlCommand command = new SqlCommand(query, connection);
                Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    EmployeeControllers employees = new Employee
                    {
                        Id = Convert.ToInt32(reader["ID"]),
                        FisrtName = reader["FirstName"].ToString(),
                        MiddleName = reader["MiddleName"].ToString(),
                        LastName = reader["LastName"].ToString(),
                        DOB = Convert.ToDateTime(reader["DOB"]),
                        Salary = Convert.ToDecimal(reader["Salary"]),
                        DepartmentId = Convert.ToInt32(reader["DepartmentId"])

                    };
                    employees.Add(employee);
                }


                
            }
            return View(employees);



        }

       public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee employee)
        {
            if(ModelState.IsValid)
            {

            }
            return View(employee);
        }


        public ActionResult Edit(int id)
        {
            return View();
        }

        [HttpPost]
        public ActionResult Edit(Employee employee)
        {
            if(ModelState.IsValid)
            { 


            }
            return View(employee);
        }

        public ActionResult Delete(int id)
        {
            return View();
        }

        [HttpDelete]
        public ActionResult DeleteConfirmed(int id)
        {
            return View();
        }


    }
}
