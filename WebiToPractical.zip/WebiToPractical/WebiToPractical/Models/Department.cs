﻿namespace WebiToPractical.Models
{
    public class Department
    {
        public int Id{ get; set; }

        public string DepartmentName {  get; set; }

        public bool IsActive { get; set; }
    }
}
