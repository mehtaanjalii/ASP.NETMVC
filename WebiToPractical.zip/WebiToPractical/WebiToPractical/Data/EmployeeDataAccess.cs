﻿using Microsoft.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace WebiToPractical.Data
{
    public class EmployeeDataAccess
    {
        private string connectionString = "Practical";

        public void AddEmployee(Employee employee)
        {
            string query = "INSERT INTO Employee(FirstName , MiddleName, lastName, DOB , Salary , DepartmentId ) Values(@FisrtName, @MiddleName, @ LastName , @DOb , @Salary,@DepartmentId)";
            SqlCommand command = new SqlCommand(query connection);
            command.Parameters.AddWithValue("@FirstName" , employee.FirstName);
            command.Parameters.AddWithValue("@MiddleName", employee.MiddleName);
            command.Parameters.AddWithValue("@LastName", employee.LastName);
            command.Parameters.AddWithValue("@DOB", employee.DOB);
            command.Parameters.AddWithValue("@Salary", employee.Salary);
            command.Parameters.AddWithValue("@DepartmentId", employee.DepartmentId);
            connection.Open();
            command.ExecuteNonQuery();


        }
    }
}
